import React from 'react'
import './Header.css'
const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2>order your favourite food here</h2>
        <p>chose from a divers menu feturing adelectable array of dishes crafed with the finenst ingredients and alevente your dining experience,one deliciuos meal at atime </p>
      <button>View Menu</button>
      </div>
    </div>
  )
}

export default Header
