import React from 'react'
import Xasa from './components/Foods/Xasa'

const app = () => {
  return (
    <div className='app'>
      <Xasa/>
      
     
    </div>
  )
}

export default app
